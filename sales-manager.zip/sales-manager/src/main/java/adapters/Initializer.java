package adapters;

/**
 * Created by u624 on 3/24/17.
 */
@FunctionalInterface
public interface Initializer {
    void init();
}
